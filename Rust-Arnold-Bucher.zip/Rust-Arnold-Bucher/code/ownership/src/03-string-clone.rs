fn main() {
    let s1 = String::from("hello");
    let s2 = s1.clone();
    println!("{}, world!", s1);
}
